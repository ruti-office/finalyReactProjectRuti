import Fab from '@mui/material/Fab';
import EditIcon from '@mui/icons-material/Edit';
import EditBD from './EditBD';
import { useState } from 'react';
function BD() {
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  return (
    <>
      <div>
        <h1>שיעורים פרטיים</h1>
        <h2>סביון 35</h2>
        <h2>050.5555555</h2>
        <div>
        <Fab color="secondary" aria-label="edit"onClick={handleClickOpen}>
        <EditIcon />
      </Fab>
      </div>

    </div >
<EditBD openDialog={open} setOpenDialog={setOpen}/>
{/* <Service/> */}
    </>
  )
}

export default BD