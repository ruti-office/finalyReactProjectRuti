import axios from "axios"

import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import { useState } from 'react';

function Login(props) {
    const {x}=props
    const [userName, setUserName] = useState()
    const [password, setPassword] = useState()
    //const [alertSuccess, setAlertSuccess] = useState(false)     לא הלך לנו לעשות את ההודעה הקופצת
    //const [alertFailed, setAlertFailed] = useState(false)


    const handleLogin = () => {
        axios.post("http://localhost:8787/login", { "name": userName, "password": password })
            .then(res => {
                if (res.data === "Login success!") {
                    x(true)
                    // setAlertSuccess(true)
                    alert('התחברת בהצלחה')
                }
                // else {
                //     setIsLogin
                //     alert('שם משתמש / סיסמה שגוי')
                // }

            })
            .catch(err => {

                alert('שגיאה בהתחברות')
            })

    }
    return (
        <>
            <div>
                <TextField id="outlined-basic" label="User Name" variant="outlined" onChange={e => setUserName(e.target.value)} />
            </div>
            <div>
                <TextField id="outlined-basic" type ="password" label="Password" variant="outlined" onChange={e => setPassword(e.target.value)} />
            </div>
            <div>
                <Button variant="Login" onClick={handleLogin}>LOGIN</Button>
            </div>

            {/* <Alert severity="success">           קשור להודעת שגיאה שעשינו
                <AlertTitle>  התחברת בהצלחה</AlertTitle>
                זוהית כמנהל</Alert>
            <Alert severity="error">
                <AlertTitle>שגיאה</AlertTitle>
                שגיאה בהתחברת</Alert> */}


        </>
    )
}

export default Login