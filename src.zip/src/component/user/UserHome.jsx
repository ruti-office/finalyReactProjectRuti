function UserHome() {


    return (
      <>
      <h1>User page</h1>
        </> 
    )
  }
  
  export default UserHome