import { useState } from "react"
import Login from "./Login"
import BD from "./BD"
import ServicesList from "./ServicesList"
function AdminHome() {
  const [isLogin, setIsLogin] = useState(false)

  return (
    <>
      {
        isLogin ?
         <>
          <BD />
          <ServicesList/>         
          </> :
          <Login x={setIsLogin}/>
      }

     

    </>
  )
}

export default AdminHome