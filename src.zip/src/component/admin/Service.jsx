import Card from '@mui/joy/Card';

function Service() {

  return (
    <>
      <Card size="מתמטיקה">Large card</Card>
      <Card size="עברית">Large card</Card>
      <Card size="english">Large card</Card>
    </>
  )
}

export default Service