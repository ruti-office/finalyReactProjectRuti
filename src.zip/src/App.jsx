import Route from "./component/Route"
import AdminHome from "./component/admin/AdminHome"
import BD from "./component/admin/BD"
import Login from "./component/admin/Login"
import UserHome from "./component/user/UserHome"
function App() {


  return (
    <>
    <Route/>
      </> 
  )
}

export default App
